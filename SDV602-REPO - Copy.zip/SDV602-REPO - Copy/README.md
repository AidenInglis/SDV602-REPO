# SDV602-REPO

To run this game navigate to the AS1 directory then in your bash terminal type in python main.py


Allowed Commands by Room
Room1
- Commands: left, right
Room2
- Commands: left, right
Room3
- Commands: left, right, pickup
Room4
- Commands: left, right
Room5
- Commands: yes (to enter BossRoom), no (to go back to Room4)
BossRoom
- Commands: yes (to enter BossFight), no (to go back to Room4)
TooLate
- Commands: yes (to enter BossFight)
BossFight
- Commands: attack, heal
Win
- Commands: Exit
Lose
- Commands: Exit



Problems:
1. Images haven't been added and are just too zoomed in or are default ones from the example.
2. you can go to room3 pickup the potion navigate around the map, press pickup again, it will then break the game.
3. When you press attack the details update correctly, but when you type attack and press enter the details don't update and then if you use the button method you need to press the enter button after the monster health is below 0 to be taken to the win screen.