import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


#some of this code has been adapted from the following source: 
# https://matplotlib.org/stable/gallery/lines_bars_and_markers/bar_colors.html
def draw_chart(canvas):
    #create a matplotlib for chart
    fig, ax = plt.subplots(figsize=(3, 3))

    #data for the bar chart
    fruits = ['apple', 'blueberry', 'cherry', 'orange']
    counts = [40, 100, 30, 55]

    #create the bar chart with the above details
    ax.bar(fruits, counts)

    # Set chart labels and title
    ax.set_ylabel('Fruit Supply')
    ax.set_title('Fruit Supply by Kind')

    # Draw the chart into the provided canvas

    #provided by https://www.tutorialspoint.com/pysimplegui/pysimplegui_matplotlib_integration.htm for my example chart.
    figure_canvas = FigureCanvasTkAgg(fig, canvas.TKCanvas)
    figure_canvas.draw()
    figure_canvas.get_tk_widget().pack(side='top', fill='both', expand=False)
