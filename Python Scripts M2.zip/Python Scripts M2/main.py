import PySimpleGUI as sg#import PySimpleGUI as sg
from screens import create_lobby, create_screen1, create_screen2, create_screen3  # Import the functions
from chart import draw_chart#import the draw_chart function
import matplotlib.pyplot as plt #will use for charts in the future

def main():
    # Initial screen
    window_size = (850, 450)#default window size set
    screen = create_lobby()#starting with the lobby screen as login not required in this part yet.
    window = sg.Window('Data Analyst Program', screen, size=window_size, finalize=True)#Creating the window
    chat_logs = {'screen1': [], 'screen2': [], 'screen3': []}#Dict for storing chats
    
    while True:#while loop = true, when false it will stop
        event, values = window.read()#clicks/input read from window.
        
        if event in (sg.WIN_CLOSED, 'Exit'):#when Exit clicked end loop and close window
            break#break loop
        elif event == 'Screen 1':#if screen 1, close old window and open new window with chart 1
            window.close()
            window = sg.Window('Screen 1', create_screen1(), size=window_size, finalize=True)
            draw_chart(window['chart1_placeholder'])#draw chart 1
        elif event == 'Screen 2':#if screen 2, close old window and open new window with chart 2
            window.close()
            window = sg.Window('Screen 2', create_screen2(), size=window_size, finalize=True)
            draw_chart(window['chart2_placeholder'])#draw chart 2
        elif event == 'Screen 3':#if screen 3, close old window and open new window with chart 3
            window.close()
            window = sg.Window('Screen 3', create_screen3(), size=window_size, finalize=True)
            draw_chart(window['chart3_placeholder'])#draw chart 3
        elif event == 'Back to Lobby':#if back to lobby, close old window and open new window with lobby
            window.close()
            window = sg.Window('Chart Application', create_lobby(), size=window_size)
        elif event == 'Send Chat 1':#if send chat 1, add message to chat log and update the chat-area with the new message
            new_message = values['screen1_chat_input']#delcare new message as the input
            if new_message:#when new message is not empty
                chat_logs['screen1'].append(f'User: {new_message}')#appends the message to screen1 dict chatlog
                window['screen1_chat'].update('\n'.join(chat_logs['screen1']))#update the chat-area with new message.
                window['screen1_chat_input'].update('')#Clear the input box

    window.close()#NOTE: close window

if __name__ == "__main__":#
    main()